//
//  GameScene.swift
//  Pierre Penguin Escapes the Antarctic
//

import SpriteKit

class GameScene: SKScene {
    // Create the world as a generic SKNode
    let world = SKNode()
    // Create our bee node as a property of GameScene so we can access it throughout the class
    let bee = SKSpriteNode()
    
    override func didMoveToView(view: SKView) {
        self.backgroundColor = UIColor(red: 0.4, green: 0.6, blue:
            0.95, alpha: 1.0)
        
        // Add the world node as a child of the scene
        self.addChild(world)
        // Call the new bee function
        self.addTheFlyingBee()
    }
    
    // I moved all of our bee animation code into this new function
    func addTheFlyingBee() {
        // Position our bee
        bee.position = CGPoint(x: 250, y: 250)
        bee.size = CGSize(width: 28, height: 24)
        // Notice we now attach our bee node to the world, instead of the scene:
        world.addChild(bee)
        
        // Find our new bee texture atlas
        let beeAtlas = SKTextureAtlas(named:"bee.atlas")
        // Grab the two frames we want from the texture atlas into an array
        let beeFrames:[SKTexture] = [beeAtlas.textureNamed("bee.png"), beeAtlas.textureNamed("bee_fly.png")]
        // Create a new SKAction to animate between the frames
        let flyAction = SKAction.animateWithTextures(beeFrames, timePerFrame: 0.14)
        // Finally create an SKAction that will execute the flyAction repeatedly
        let beeAction = SKAction.repeatActionForever(flyAction)
        // Instruct our bee to run the final action
        bee.runAction(beeAction)
        
        // Set up the actions to move our bee to and fro:
        // The following two moveByX actions move a node 200 points in either direction
        let pathLeft = SKAction.moveByX(-200, y: -10, duration: 2)
        let pathRight = SKAction.moveByX(200, y: 10, duration: 2)
        // These two scaleXTo actions flip the texture back and forth
        // We will use these to turn the bee in the direction its flying
        let flipTextureNegative = SKAction.scaleXTo(-1, duration: 0)
        let flipTexturePositive = SKAction.scaleXTo(1, duration: 0)
        // Combine these actions into a cohesive flight path for our bee
        let flightOfTheBee = SKAction.sequence([pathLeft, flipTextureNegative, pathRight, flipTexturePositive])
        // Last, create a looping action that will repeat forever
        let neverEndingFlight = SKAction.repeatActionForever(flightOfTheBee)
        
        // Tell our bee to run the flight path, and away it goes!
        bee.runAction(neverEndingFlight)
    }
    
    override func didSimulatePhysics() {
        // To find the correct position, subtract half of the scene size
        // from the bee's position, adjusted for any world scaling
        // Multiply by -1 and you have the adjustment to keep our sprite centered
        let worldXPos = -(bee.position.x * world.xScale-(self.size.width / 2))
        let worldYPos = -(bee.position.y * world.yScale-(self.size.height / 2))
        // Move the world so that the bee is centered in the scene
        world.position = CGPoint(x: worldXPos, y: worldYPos)
    }
}