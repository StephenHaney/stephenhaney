//
//  GameScene.swift
//  Pierre Penguin Escapes the Antarctic
//

import SpriteKit

class GameScene: SKScene {
    override func didMoveToView(view: SKView) {
    }
}