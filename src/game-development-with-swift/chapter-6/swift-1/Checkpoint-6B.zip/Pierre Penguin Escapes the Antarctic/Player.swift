//
//  Player.swift
//  Pierre Penguin Escapes the Antarctic
//

import SpriteKit

class Player : SKSpriteNode, GameSprite {
    var textureAtlas:SKTextureAtlas = SKTextureAtlas(named:"pierre.atlas")
    var flyAnimation = SKAction()
    var soarAnimation = SKAction()
    // Keep track of whether we're flapping our wings or in free-fall:
    var flapping = false
    // 57,000 is a force that feels good to me, you can adjust to taste:
    let maxFlappingForce:CGFloat = 57000
    // We want Pierre to slow down when he flies too high:
    let maxHeight:CGFloat = 1000
    
    func spawn(parentNode:SKNode, position: CGPoint, size: CGSize = CGSize(width: 64, height: 64)) {
        parentNode.addChild(self)
        createAnimations()
        self.size = size
        self.position = position
        self.runAction(soarAnimation, withKey: "soarAnimation")
        
        let physicsTexture = textureAtlas.textureNamed("pierre-flying-3.png")
        self.physicsBody = SKPhysicsBody(
            texture: physicsTexture,
            size: size)
        self.physicsBody?.allowsRotation = false
        self.physicsBody?.linearDamping = 0.9
        self.physicsBody?.mass = 30
    }
    
    func createAnimations() {
        let rotateUpAction = SKAction.rotateToAngle(0, duration: 0.475)
        rotateUpAction.timingMode = .EaseOut
        let rotateDownAction = SKAction.rotateToAngle(-1, duration: 0.8)
        rotateDownAction.timingMode = .EaseIn
        
        // Create the flying animation:
        let flyFrames:[SKTexture] = [
            textureAtlas.textureNamed("pierre-flying-1.png"),
            textureAtlas.textureNamed("pierre-flying-2.png"),
            textureAtlas.textureNamed("pierre-flying-3.png"),
            textureAtlas.textureNamed("pierre-flying-4.png"),
            textureAtlas.textureNamed("pierre-flying-3.png"),
            textureAtlas.textureNamed("pierre-flying-2.png")
        ]
        let flyAction = SKAction.animateWithTextures(flyFrames, timePerFrame: 0.03)
        flyAnimation = SKAction.group([
            SKAction.repeatActionForever(flyAction),
            rotateUpAction
        ])
        
        // Create the soaring animation, just one frame for now:
        let soarFrames:[SKTexture] = [textureAtlas.textureNamed("pierre-flying-1.png")]
        let soarAction = SKAction.animateWithTextures(soarFrames, timePerFrame: 1)
        soarAnimation = SKAction.group([
            SKAction.repeatActionForever(soarAction),
            rotateDownAction
        ])
    }
    
    func update() {
        // If we are flapping, apply a new force to push Pierre higher.
        if (self.flapping) {
            var forceToApply = maxFlappingForce
            
            // Apply less force if Pierre is above position 600
            if (position.y > 600) {
                // We will apply less and less force the higher Pierre goes.
                // These next three lines determine just how much force to mitigate:
                let percentageOfMaxHeight = position.y / maxHeight
                let flappingForceSubtraction = percentageOfMaxHeight * maxFlappingForce
                forceToApply -= flappingForceSubtraction
            }
            // Apply the final force:
            self.physicsBody?.applyForce(CGVector(dx: 0, dy: forceToApply))
        }
        
        // We need to limit Pierre's top speed as he shoots up the y-axis.
        // This prevents him from building up enough momentum to shoot high
        // over our max height. We are bending the physics to improve the gameplay:
        if (self.physicsBody?.velocity.dy > 300) {
            self.physicsBody?.velocity.dy = 300
        }
        
        // Set a constant velocity to the right:
        self.physicsBody?.velocity.dx = 200
    }
    
    // Begin the flapping animation, and set the flapping property to true:
    func startFlapping() {
        self.removeActionForKey("soarAnimation")
        self.runAction(flyAnimation, withKey: "flapAnimation")
        self.flapping = true
    }
    
    // Start the soar animation, and set the flapping property to false:
    func stopFlapping() {
        self.removeActionForKey("flapAnimation")
        self.runAction(soarAnimation, withKey: "soarAnimation")
        self.flapping = false
    }
    
    func onTap() {}
}