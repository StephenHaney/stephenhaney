//
//  GameScene.swift
//  Pierre Penguin Escapes the Antarctic
//

import SpriteKit

class GameScene: SKScene {
    let world = SKNode()
    let player = Player()
    let ground = Ground()
    
    override func didMoveToView(view: SKView) {
        // Set a sky-blue background color:
        self.backgroundColor = UIColor(red: 0.4, green: 0.6, blue: 0.95, alpha: 1.0)
        
        // Add the world node as a child of the scene:
        self.addChild(world)
        
        // Spawn our physics bees:
        let bee2 = Bee()
        let bee3 = Bee()
        let bee4 = Bee()
        bee2.spawn(world, position: CGPoint(x: 325, y: 325))
        bee3.spawn(world, position: CGPoint(x: 200, y: 325))
        bee4.spawn(world, position: CGPoint(x: 50, y: 200))
        
        // Spawn the ground:
        let groundPosition = CGPoint(x: -self.size.width, y: 100)
        let groundSize = CGSize(width: self.size.width * 3, height: 0)
        ground.spawn(world, position: groundPosition, size: groundSize)
        
        // Spawn the player:
        player.spawn(world, position: CGPoint(x: 150, y: 250))
        
        // Push bee2 towards bee 3
        bee2.physicsBody?.mass = 0.2
        bee2.physicsBody?.applyImpulse(CGVector(dx: -15, dy: 0))
    }
    
    override func didSimulatePhysics() {
        // To find the correct position, subtract half of the scene size
        // from the player's position, adjusted for any world scaling.
        // Multiply by -1 and you have the adjustment to keep our player centered.
        let worldXPos = -(player.position.x * world.xScale - (self.size.width / 2))
        let worldYPos = -(player.position.y * world.yScale - (self.size.height / 2))
        // Move the world for our adjustment:
        world.position = CGPoint(x: worldXPos, y: worldYPos)
    }
}