(function () { // :)
    'use strict';

    window.grove = {
        objectTemplates: [],

        sounds: [],

        currentKeyboard: {},

        lastUpdate: 0,
        worldWidth: 0,
        worldHeight: 0,
        rockSize: 70,

        levels: [],

        hud: null,

        hero: null,
        baddies: [],
        fireballs: [],
        structures: [],
        goals: [],
        edges: { left: 0, right: 0, top: 0, bottom: 0 },

        canvasBack: null,
        canvasAction: null,
        canvasFore: null,
        canvasGui: null,

        ctxBack: null,
        ctxAction: null,
        ctxFore: null,
        ctxGui: null,

        paused: false,

        initialize: function() {
            // init sounds!
            grove.initSounds();

            // wait for DOM then create the unique views
            $(function () {
                // keep track of key downs and ups
                $(window).keydown(grove.keyDown);
                $(window).keyup(grove.keyUp);

                // grab canvas contexts, world size, and set up initial background color
                grove.canvasBack = document.getElementById('canvas-background');
                grove.canvasAction = document.getElementById('canvas-action');
                grove.canvasFore = document.getElementById('canvas-foreground');
                grove.canvasFlying = document.getElementById('canvas-flying');
                grove.canvasGui = document.getElementById('canvas-gui');
                grove.worldWidth = grove.canvasBack.width;
                grove.worldHeight = grove.canvasBack.height;

                grove.ctxBack = grove.canvasBack.getContext('2d');
                grove.ctxAction = grove.canvasAction.getContext('2d');
                grove.ctxFore = grove.canvasFore.getContext('2d');
                grove.ctxFlying = grove.canvasFlying.getContext('2d');
                grove.ctxGui = grove.canvasGui.getContext('2d');

                // scale the canvas to fit the viewport
                grove.scaleCanvasToScreen();

                grove.ctxAction.save(); // save default state
                grove.ctxFlying.save(); // save default state

                // create our hero
                grove.hero = new grove.objectTemplates.Hero();

                // build the HUD
                grove.hud = new grove.objectTemplates.Hud();

                // wait for images to load and then load level 0!
                $('body').waitForImages(function() {
                    grove.changeLevel(0);
                    tween.to($('#cover'), 0.6, { autoAlpha: 0 });
                });

                // let's get started
                grove.loopy();
            });
        },

        scaleCanvasToScreen: function() {
            var heightDifference = this.worldHeight - $(window).height();
            var widthDifference = this.worldWidth - $(window).width();
            var heightScaleRatio = 1;
            var widthScaleRatio = 1;
            var newScaleRatio = 1;

            if (heightDifference > 0) {
                heightScaleRatio = 1 - (heightDifference / this.worldHeight);
            }
            if (widthDifference > 0) {
                widthScaleRatio = 1 - (widthDifference / this.worldWidth);
            }

            if (heightScaleRatio < 1 && heightScaleRatio < widthScaleRatio) {
                newScaleRatio = heightScaleRatio;
            }
            else if (widthScaleRatio < 1) {
                newScaleRatio = widthScaleRatio;
            }

            tween.set(grove.canvasBack, { scale: newScaleRatio });
            tween.set(grove.canvasAction, { scale: newScaleRatio });
            tween.set(grove.canvasFore, { scale: newScaleRatio });
            tween.set(grove.canvasFlying, { scale: newScaleRatio });
            tween.set(grove.canvasGui, { scale: newScaleRatio });
        },

        initSounds: function() {
            // song
            grove.sounds.main = new Howl({
                urls: ['sounds/wardens-song.mp3'],
                loop: true,
                volume: 0.5
            });
            grove.sounds.main.play();

            grove.sounds.damage = new Howl({
                urls: ['sounds/hurt.mp3'],
                volume: 0.3
            });

            grove.sounds.heal = new Howl({
                urls: ['sounds/heal.mp3'],
                volume: 0.2
            });

            grove.sounds.death = new Howl({
                urls: ['sounds/death.mp3'],
                volume: 0.4
            });

            grove.sounds.attack = new Howl({
                urls: ['sounds/attack.mp3'],
                volume: 0.3
            });

            grove.sounds.transform = new Howl({
                urls: ['sounds/transform.mp3'],
                volume: 0.2
            });

            grove.sounds.fireball = new Howl({
                urls: ['sounds/fireball.mp3'],
                volume: 0.2
            });
        },

        // Load all images
        initImages: function() {
            for (var i = 0; i < this.images.length; i++) {
                var loadImage = new Image();
                loadImage.src = this.images[i];
            }
        },

        keyDown: function(e) {
            // Store the key as a current key
            grove.currentKeyboard[e.keyCode] = true;

            // transform to druid
            if (e.keyCode === 49) {
                grove.hero.shapeshift('druid');
                return;
            }
            // transform to wolf
            if (e.keyCode === 50) {
                grove.hero.shapeshift('wolf');
                return;
            }
            if (e.keyCode === 51) {
                grove.hero.shapeshift('owl');
            }

            // keep track of the last direction the player moved
            // Directions: 0 down, 1 left, 2 right, 3 up
            // towards the top
            if (e.keyCode === 38 || e.keyCode === 87) {
                grove.hero.lastDirection.both = 3;
                grove.hero.lastDirection.y = 3;
            }
            // towards the bottom
            else if (e.keyCode === 40 || e.keyCode === 83) {
                grove.hero.lastDirection.both = 0;
                grove.hero.lastDirection.y = 0;
            }
            // towards the left
            else if (e.keyCode === 37 || e.keyCode === 65) {
                grove.hero.lastDirection.both = 1;
                grove.hero.lastDirection.x = 1;
            }
            // towards the right
            else if (e.keyCode === 39 || e.keyCode === 68) {
                grove.hero.lastDirection.both = 2;
                grove.hero.lastDirection.x = 2;
            }
        },

        keyUp: function(e) {
            grove.currentKeyboard[e.keyCode] = false;
        },

        loopy: function() {
            requestAnimationFrame(grove.loopy);
            // don't loop if paused
            if (grove.paused) { return; }

            var current = Date.now();
            var deltaTime = current - grove.lastUpdate;
            grove.lastUpdate = current;

            // cap delta time at 0.1 second to account for losing window focus
            if (deltaTime > 100) {
                deltaTime = 100;
            }

            deltaTime = deltaTime / 10;
            grove.updateWorld(deltaTime);
            grove.drawAllTheThings(deltaTime);
        },

        updateWorld: function(deltaTime) {
            // don't update if paused
            if (grove.paused) { return; }

            this.hero.update(deltaTime);

            // Update baddies
            for (var bi = 0; bi < this.baddies.length; bi++) {
                this.baddies[bi].update(deltaTime);
            }

            // Update fireballs
            for (var fi = 0; fi < this.fireballs.length; fi++) {
                this.fireballs[fi].update(deltaTime);
            }

            // Update goals
            for (var gi = 0; gi < this.goals.length; gi++) {
                this.goals[gi].update();
            }
        },

        drawAllTheThings: function(deltaTime) {
            this.ctxAction.clearRect(0, 0, this.worldWidth, this.worldHeight);
            this.ctxGui.clearRect(0, 0, this.hud.size.width, this.hud.size.height);

            // if we're flying, also clear the flying canvas
            if (this.hero.flying) {
                this.clearTheSkies();
            }

            // Baddie draw call
            for (var bi = 0; bi < this.baddies.length; bi++) {
                this.baddies[bi].draw(deltaTime);
            }

            // Hero draw call
            this.hero.draw(deltaTime);

            // Fireball draw call
            for (var fi = 0; fi < this.fireballs.length; fi++) {
                this.fireballs[fi].draw(deltaTime);
            }

            // Hud draw call:
            this.hud.draw();
        },

        // clears the sky canvas
        clearTheSkies: function() {
            this.ctxFlying.clearRect(0, 0, this.worldWidth, this.worldHeight);
        },

        changeLevel: function(index) {
            var newLevel = this.levels[index];
            if (typeof newLevel !== typeof void 0) {
                this.despawnLevel();

                // edge adjustments
                this.edges.left = grove.rockSize - newLevel.edgeAdjustments.left;
                this.edges.right = grove.worldWidth - grove.rockSize + newLevel.edgeAdjustments.right;
                this.edges.top = grove.rockSize - newLevel.edgeAdjustments.top;
                this.edges.bottom = grove.worldHeight - grove.rockSize + newLevel.edgeAdjustments.bottom;

                // background ctx 
                var bgImage = new Image();
                bgImage.src = newLevel.backgroundImageSrc;
                bgImage.onload = function() {
                    grove.ctxBack.drawImage(bgImage, 0, 0, 1920, 1024);
                };

                // background ctx - goals
                for (var gi = 0; gi < newLevel.goals.length; gi++) {
                    var newGoal = new grove.objectTemplates.Goal(newLevel.goals[gi]);
                    grove.goals.push(newGoal);

                    newGoal.draw(grove.ctxFlying);
                }

                // foreground ctx – trees
                for (var i = 0; i < newLevel.trees.length; i++) {
                    var newTree = new grove.objectTemplates.Tree(newLevel.trees[i]);
                    grove.structures.push(newTree);

                    var treeImage = new Image();
                    treeImage.src = 'img/tree.png';
                    
                    grove.ctxFore.drawImage(treeImage, newTree.position.x, newTree.position.y, newTree.size.width, newTree.size.height);
                }

                // action ctx – elementals
                for (var elementalIndex = 0; elementalIndex < newLevel.elementals.length; elementalIndex++) {
                    var newBaddie = new grove.objectTemplates.badFireElemental(newLevel.elementals[elementalIndex]);
                    grove.baddies.push(newBaddie);
                }
            }
        },

        despawnLevel: function() {
            this.baddies = [];
            this.structures = [];
            this.goals = [];

            grove.ctxBack.clearRect(0, 0, grove.canvasBack.width, grove.canvasBack.height);
            grove.ctxAction.clearRect(0, 0, grove.canvasAction.width, grove.canvasAction.height);
            grove.ctxFore.clearRect(0, 0, grove.canvasFore.width, grove.canvasFore.height);
        },

        // pass a game object to test against, the new test location, and the test's real location
        // returns false if no collision
        // if there is a collision
        // - and you pass a realPosition: returns max distance you can move without a collision if there would be one
        // - you don't pass a realPosition: returns true
        checkForCollision: function(outwardObject, testLocation, realPosition) {
            var outwardPhysicsBody;
            // Build a physics body out of the object's own stats if it doesn't specify
            if (typeof outwardObject.physicsBody === typeof void 0) {
                outwardPhysicsBody = {
                    x: outwardObject.position.x,
                    y: outwardObject.position.y,
                    width: outwardObject.size.width,
                    height: outwardObject.size.height
                };
            }
            else {
                outwardPhysicsBody = {
                    x: outwardObject.physicsBody.x,
                    y: outwardObject.physicsBody.y,
                    width: outwardObject.physicsBody.width,
                    height:outwardObject.physicsBody.height
                };

                // add in the object's positioning
                outwardPhysicsBody.x += outwardObject.position.x;
                outwardPhysicsBody.y += outwardObject.position.y;
            }

            if (testLocation.position.x < outwardPhysicsBody.x + outwardPhysicsBody.width &&
                testLocation.position.x + testLocation.size.width > outwardPhysicsBody.x &&
                testLocation.position.y < outwardPhysicsBody.y + outwardPhysicsBody.height &&
                testLocation.position.y + testLocation.size.height > outwardPhysicsBody.y) {
                // collision!
                var result = true;

                if (typeof realPosition !== typeof undefined) {
                    result = {
                        x: null,
                        y: null
                    };

                    // if we passed a real location, we want to know the direction of the collision
                    if (testLocation.position.x < outwardPhysicsBody.x + outwardPhysicsBody.width && 
                        realPosition.x >= outwardPhysicsBody.x + outwardPhysicsBody.width) {
                        // left side
                        result.x = outwardPhysicsBody.x + outwardPhysicsBody.width;
                    }
                    else if (testLocation.position.x + testLocation.size.width > outwardPhysicsBody.x && 
                        realPosition.x + testLocation.size.width <= outwardPhysicsBody.x) {
                        // right side
                        result.x = outwardPhysicsBody.x - testLocation.size.width;
                    }
                    else if (testLocation.position.y < outwardPhysicsBody.y + outwardPhysicsBody.height && 
                        realPosition.y >= outwardPhysicsBody.y + outwardPhysicsBody.height) {
                        // top side
                        result.y = outwardPhysicsBody.y + outwardPhysicsBody.height;
                    }
                    else if (testLocation.position.y + testLocation.size.height > outwardPhysicsBody.y && 
                        realPosition.y + testLocation.size.height <= outwardPhysicsBody.y) {
                        // bottom side
                        result.y = outwardPhysicsBody.y - testLocation.size.height;
                    }
                }

                return result;
            }

            return false;
        }
    };

    grove.initialize();

})(); // :D