(function () { // :)
    'use strict';

    grove.objectTemplates.Hero = function() {
        this.initialLife = 100;
        this.life = this.initialLife - 30;
        this.displayLife = this.life;

        this.speed = 3.65;
        this.attackDamage = 10;

        this.initialSize = { width: 64, height: 64 };
        this.size = { width: this.initialSize.width, height: this.initialSize.height };
        this.origin = {
            x: this.size.width / 2,
            y: this.size.height / 2
        };

        this.initialPosition = { x: 928, y: 300 };
        this.position = this.initialPosition;

        this.currentFormName = 'druid';
        this.forms = {
            druid: {
                size: { width: 64, height: 64 },
                animationFrameCount: 2,
                millisecondsPerFrame: 13,
                speed: 3.65,
                imageIndex: 0,
                abilityDelay: 1000,
                alwaysAnimating: false,
                flying: false
            },
            wolf: {
                size: { width: 100, height: 100 },
                animationFrameCount: 7,
                millisecondsPerFrame: 5,
                speed: 5,
                imageIndex: 1,
                abilityDelay: 600,
                alwaysAnimating: false,
                flying: false
            },
            owl: {
                size: { width: 80, height: 80 },
                animationFrameCount: 2,
                millisecondsPerFrame: 10,
                speed: 6,
                imageIndex: 2,
                abilityDelay: 5000,
                alwaysAnimating: true,
                flying: true
            }
        };

        // Images: 0 druid, 1 wolf
        this.imageIndex = 0;
        this.images = [new Image(), new Image(), new Image()];
        this.images[0].src = 'img/hero.png';
        this.images[1].src = 'img/hero-wolf.png';
        this.images[2].src = 'img/hero-owl.png';

        this.healing = false;
        this.attacking = {
            animating: false
        };
        this.attackBox = null;
        this.attackAnimationSpeed = 275;
        this.attackImage = new Image();
        this.attackImage.src = 'img/claw-attack.png';
        this.attackImage.size = {
            vertical: {
                width: 133,
                height: 43
            },
            horizontal: {
                width: 43,
                height: 133
            }
        };
        this.attackImage.origin = {
            vertical: {
                x: this.attackImage.size.vertical.width / 2,
                y: this.attackImage.size.vertical.height / 2
            },
            horizontal: {
                x: this.attackImage.size.horizontal.width / 2,
                y: this.attackImage.size.horizontal.height / 2
            }
        };
        this.attackImage.offsets = {
            top: { x: 0, y: 0},
            bottom: { x: 0, y: 43 },
            left: { x: 133, y: 0 },
            right: { x: 176, y: 0 },
        };

        // Directions: 0 down, 1 left, 2 right, 3 up
        this.lastDirection = {
            x: 1,
            y: 0,
            both: 0
        };
        this.animationDirection = 0;

        // Animation
        this.alwaysAnimating = false;
        this.millisecondsPerFrame = this.forms.druid.millisecondsPerFrame;
        this.animationFrameCount = this.forms.druid.animationFrameCount; // 0 based count
        this.animationFrame = 0;
        this.timeSinceLastAnimation = 0;

        this.abilityDelay = this.forms.druid.abilityDelay;
        this.lastAbility = 0;
        this.lastDamageTaken = 0;
        this.opacity = 1;
        this.flying = false;

        this.shapeshift = function(newFormName) {
            this.animationFrame = 0;
            this.timeSinceLastAnimation = 0;
            var newForm;

            if (newFormName === 'druid') {
                newForm = this.forms.druid;
            }
            else if (newFormName === 'wolf') {
                newForm = this.forms.wolf;
            }
            else if (newFormName === 'owl') {
                newForm = this.forms.owl;
            }

            grove.sounds.transform.play();

            // Tell the sky canvas to clear in case we're switching away from flying:
            grove.clearTheSkies();

            this.currentFormName = newFormName;
            this.size = newForm.size;
            this.origin = {
                x: this.size.width / 2,
                y: this.size.height / 2
            };
            this.animationFrameCount = newForm.animationFrameCount;
            this.millisecondsPerFrame = newForm.millisecondsPerFrame;
            this.imageIndex = newForm.imageIndex;
            this.speed = newForm.speed;
            this.abilityDelay = newForm.abilityDelay;
            this.alwaysAnimating = newForm.alwaysAnimating;
            this.flying = newForm.flying;
            this.lastAbility = 0;

            // Update the HUD with the new form:
            grove.hud.switchForm(newFormName);
        };

        this.ability = function() {
            var current = Date.now();

            // throttle:
            if (current > this.lastAbility + this.abilityDelay) {
                // Attack!
                this.lastAbility = current;

                if (this.currentFormName === 'druid') {
                    // cast a healing spell
                    this.cast('heal');
                }
                else if (this.currentFormName === 'wolf') {
                    this.cast('attack');
                }
            }
        };

        this.cast = function(abilityName) {
            if (abilityName === 'heal' && this.healing === false) {
                grove.sounds.heal.play();
                this.healing = true;
                tween.to({}, 5, {
                    overwrite: 'none',
                    onUpdate: _.bind(this.healOverTimeTick, this),
                    onComplete: function() {
                        grove.hero.healing = false;
                    }
                });
            }
            else if (abilityName === 'attack') {
                grove.sounds.attack.play();
                this.attacking.animating = true;
                this.attacking.direction = this.lastDirection.both;
                setTimeout(function() {
                    grove.hero.attacking.animating = false;
                    grove.hero.attackBox = null;
                }, this.attackAnimationSpeed);
            }
        };

        this.healOverTimeTick = function() {
            this.life += this.initialLife * 0.00175;
            // Keep us from going over original life:
            if (this.life > this.initialLife) { this.life = this.initialLife; }
            // Tween the HUD towards the new life:
            tween.to(this, 0.3, { displayLife: this.life });
        };

        this.damage = function(amount) {
            var current = Date.now();

            // throttle:
            if (current > this.lastDamageTaken + 1200) {
                this.lastDamageTaken = current;


                this.life -= amount;
                // Tween the HUD towards the new life:
                tween.to(this, 0.3, { displayLife: this.life });

                if (this.life <= 0) {
                    // game over!
                    grove.sounds.death.play();
                    this.opacity = 0.3;
                    this.displayLife = 0;
                    grove.paused = true;
                    return;
                }
                else {
                    // play damage sound
                    grove.sounds.damage.play();
                }

                this.damageAnimation();
            }
        };

        this.damageAnimation = function() {
            // flash
            tween.to(grove.hero, 0.3, {
                opacity: 0,
                overwrite: 'none',
                onComplete: function() {
                    tween.to(grove.hero, 0.3, {
                        opacity: 1,
                        overwrite: 'none',
                        onComplete: function() {
                            tween.to(grove.hero, 0.3, {
                                opacity: 0,
                                overwrite: 'none',
                                onComplete: function() {
                                    tween.to(grove.hero, 0.3, { opacity: 1 });
                                }
                            });
                        }
                    });
                }
            });
        };

        this.draw = function(deltaTime) {
            var frameY = this.animationDirection * this.size.height;
            var frameX = this.animationFrame * this.size.width;
            // Pick a canvas to draw to:
            var canvasCtx = grove.ctxAction;
            if (this.flying) {
                canvasCtx = grove.ctxFlying;
            }

            if (this.opacity !== 1) {
                canvasCtx.globalAlpha = this.opacity;
                canvasCtx.drawImage(this.images[this.imageIndex], frameX, frameY, this.size.width, this.size.height, this.position.x, this.position.y, this.size.width, this.size.width);
                canvasCtx.globalAlpha = 1;
            }
            else {
                canvasCtx.drawImage(this.images[this.imageIndex], frameX, frameY, this.size.width, this.size.height, this.position.x, this.position.y, this.size.width, this.size.width);
            }

            if (this.attacking.animating) {
                this.drawAttack(canvasCtx);
            }
        };

        this.update = function(deltaTime) {
            var vector = { x: 0, y: 0 };
            var animating = false;

            // Check if we're attacking
            if (grove.currentKeyboard[32] === true) { this.ability(); }

            if (this.attackBox !== null) {
                // we're mid attack - check if we're hitting anything
                for (var bi = 0; bi < grove.baddies.length; bi++) {
                    // don't try to hit dead enemies:
                    if (grove.baddies[bi].health <= 0) { continue; }
                    // did we hit one?
                    var hitEnemy = grove.checkForCollision(grove.baddies[bi], this.attackBox);
                    if (hitEnemy) {
                        grove.baddies[bi].takeDamage(grove.hero.attackDamage);
                    }
                }
            }

            // Directions: 0 down, 1 left, 2 right, 3 up
            var top = (grove.currentKeyboard[38] === true || grove.currentKeyboard[87] === true);
            var bottom = (grove.currentKeyboard[40] === true || grove.currentKeyboard[83] === true);
            var left = (grove.currentKeyboard[37] === true || grove.currentKeyboard[65] === true);
            var right = (grove.currentKeyboard[39] === true || grove.currentKeyboard[68] === true);
            if (top && this.lastDirection.y !== 0) { vector.y = -1; this.animationDirection = 3; }
            if (bottom && this.lastDirection.y !== 3) { vector.y = 1; this.animationDirection = 0; }
            if (left && this.lastDirection.x !== 2) { vector.x = -1; this.animationDirection = 1; }
            else if (right && this.lastDirection.x !== 1) { vector.x = 1;  this.animationDirection = 2;}

            if ((vector.x !== 0 || vector.y !== 0) && !grove.paused) {
                // we have a movement request
                var length = Math.sqrt(vector.x * vector.x + vector.y * vector.y);

                // keep the animation going
                animating = true;

                // we'll create a new test box at the new goal location to see if we can move there
                // can't just set these equal to their objects or it'll pass by reference (essentially)
                var testBox = {
                    position: { x: this.position.x, y: this.position.y },
                    size: { width: this.size.width, height: this.size.height }
                };

                if (vector.x !== 0) {
                    vector.x /= length;
                    testBox.position.x += vector.x * this.speed * deltaTime;
                }
                if (vector.y !== 0) {
                    vector.y /= length;
                    testBox.position.y += vector.y * this.speed * deltaTime;
                }

                if (this.flying === false) {
                    // check for collisions if we're on the ground
                    var blocked = false;
                    for (var i = 0; i < grove.structures.length; i++) {
                        var collisionTest = grove.checkForCollision(grove.structures[i], testBox, this.position);
                        if (collisionTest) {
                            // we'll adjust our goal location to the farthest we can go without overlap
                            if (collisionTest.x !== null) {
                                testBox.position.x = collisionTest.x;
                            }
                            else if (collisionTest.y !== null) {
                                testBox.position.y = collisionTest.y;
                            }
                        }
                    }
                }

                this.position = testBox.position;

                // keep 'em in bounds
                var heroBottomEdge = this.position.y + this.size.height;
                var heroRightEdge = this.position.x + this.size.width;

                if (this.position.x < grove.edges.left) {
                    this.position.x = grove.edges.left;
                }
                else if (heroRightEdge > grove.edges.right) {
                    this.position.x = grove.edges.right - this.size.width;
                }

                if (this.position.y < grove.edges.top) {
                    this.position.y = grove.edges.top;
                }
                else if (heroBottomEdge > grove.edges.bottom) {
                    this.position.y = grove.edges.bottom - this.size.height;
                }
            }

            if (animating || this.alwaysAnimating) {
                // Logic for the walking animation
                this.timeSinceLastAnimation += deltaTime;
                if (this.timeSinceLastAnimation > this.millisecondsPerFrame) {
                    this.timeSinceLastAnimation = 0;
                    this.animationFrame++;
                    if (this.animationFrame > this.animationFrameCount) { this.animationFrame = 0; }
                }
            }
            else {
                // no movement requested, set to animation frame 0
                this.animationFrame = 0;
            }
        };

        // I'm so, so sorry
        // I just had to get it done without losing my mind
        this.drawAttack = function(canvasCtx) {
            var attackImgPos = { x: 0, y: 0 };
            var attackImgOffset = { x: 0, y: 0 };
            var attackImgSize = { width: 0, height: 0 };
            var current = Date.now();
            var percentOfAttack = (current - this.lastAbility) / this.attackAnimationSpeed;
            if (percentOfAttack <= 0) { percentOfAttack = 0.001; }
            if (percentOfAttack > 1) { percentOfAttack = 1; }

            canvasCtx.save();
            var translatePos = {
                x: this.position.x + this.origin.x,
                y: this.position.y + this.origin.y
            };
            canvasCtx.translate(translatePos.x, translatePos.y);
            // draw the attack graphic:
            if (this.attacking.direction === 3) {
                // up
                canvasCtx.rotate(percentOfAttack * 1.9 - 1.5);
                attackImgPos = {
                    x: -75,
                    y: -100
                };
                attackImgOffset = {
                    x: this.attackImage.offsets.top.x,
                    y: this.attackImage.offsets.top.y
                };
                attackImgSize = {
                    width: this.attackImage.size.vertical.width,
                    height: this.attackImage.size.vertical.height
                };
            }
            else if (this.attacking.direction === 0) {
                // down
                canvasCtx.rotate(percentOfAttack * -1.8 + 1.34 );
                attackImgPos = {
                    x: -75,
                    y: 60
                };
                attackImgOffset = {
                    x: this.attackImage.offsets.bottom.x,
                    y: this.attackImage.offsets.bottom.y
                };
                attackImgSize = {
                    width: this.attackImage.size.vertical.width,
                    height: this.attackImage.size.vertical.height
                };
            }
            else if (this.attacking.direction === 1) {
                // left
                canvasCtx.rotate(percentOfAttack * -2.1 + 1.7);
                attackImgPos = {
                    x: -105,
                    y: -70
                };
                attackImgOffset = {
                    x: this.attackImage.offsets.left.x,
                    y: this.attackImage.offsets.left.y
                };
                attackImgSize = {
                    width: this.attackImage.size.horizontal.width,
                    height: this.attackImage.size.horizontal.height
                };
            }
            else if (this.attacking.direction === 2) {
                // right
                canvasCtx.rotate(percentOfAttack * 1.8 - 1.2);
                attackImgPos = {
                    x: 70,
                    y: -70
                };
                attackImgOffset = {
                    x: this.attackImage.offsets.right.x,
                    y: this.attackImage.offsets.right.y
                };
                attackImgSize = {
                    width: this.attackImage.size.horizontal.width,
                    height: this.attackImage.size.horizontal.height
                };
            }

            attackImgSize.width *= percentOfAttack;
            attackImgSize.height *= percentOfAttack;
            
            canvasCtx.drawImage(this.attackImage, attackImgOffset.x, attackImgOffset.y, attackImgSize.width, attackImgSize.height, attackImgPos.x, attackImgPos.y, attackImgSize.width, attackImgSize.height);
            canvasCtx.restore();

            this.attackBox = {
                position: {
                    x: translatePos.x + attackImgPos.x,
                    y: translatePos.y + attackImgPos.y
                },
                size: {
                    width: attackImgSize.width * 2,
                    height: attackImgSize.height * 2
                }
            };

            //grove.ctxFore.fillRect(testBox.position.x, testBox.position.y, testBox.size.width, testBox.size.height);
        };
    };

})(); // :D