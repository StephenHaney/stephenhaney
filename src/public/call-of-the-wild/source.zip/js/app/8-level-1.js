(function () { // :)
    'use strict';

    grove.levels.push({
        backgroundImageSrc: 'img/background-level-1.jpg',

        edgeAdjustments: {
            left: 70,
            top: 0,
            right: 0,
            bottom: 70
        },


        elementals: [
            { x: 800, y: 550 }
        ],

        trees: [
            { x: 300, y: 100 },
            { x: 800, y: 100 },
            { x: 300, y: 720 },
            { x: 1400, y: 100 },
            { x: 1400, y: 400 },
            { x: 1400, y: 720 }
        ],

        goals: [
            {   // to the left!
                x: 0,
                y: 0,
                width: 10,
                height: 1024,
                levelIndex: 0,
                playerPosition: { x: 1780, y: 490 }
            },
            {   // to the bottom!
                x: 0,
                y: 1014,
                width: 1920,
                height: 10,
                levelIndex: 2,
                playerPosition: { x: 900, y: 40 }
            },
        ]
    });

})();