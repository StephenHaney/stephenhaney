(function () { // :)
    'use strict';

    grove.levels.push({
        backgroundImageSrc: 'img/background-level-4.jpg',

        edgeAdjustments: {
            left: 70,
            top: 0,
            right: 70,
            bottom: 0
        },

        trees: [
        ],

        elementals: [
            { x: 1600, y: 690 },
            { x: 1600, y: 490 },
            { x: 1600, y: 290 },
            { x: 1600, y: 190 },
            { x: 1600, y: 390 },
            { x: 1600, y: 790 },
            { x: 1000, y: 790 },
            { x: 1000, y: 490 },
            { x: 1000, y: 290 },
            { x: 1000, y: 190 },
            { x: 1000, y: 390 },
            { x: 400, y: 500 }
        ],

        goals: [
            {   // to the left!
                x: 0,
                y: 0,
                width: 20,
                height: 1024,
                levelIndex: 3,
                playerPosition: { x: 1780, y: 490 }
            },
            {   // to the right!
                x: 1900,
                y: 0,
                width: 20,
                height: 1024,
                levelIndex: 5,
                playerPosition: { x: 40, y: 490 }
            }
        ]
    });

})();