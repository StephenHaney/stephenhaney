(function () { // :)
    'use strict';

    grove.levels.push({
        backgroundImageSrc: 'img/background-tutorial.jpg',

        edgeAdjustments: {
            left: 0,
            top: 0,
            right: 70,
            bottom: 0
        },

        elementals: [
        ],

        trees: [
        ],

        goals: [
            {   // to the right!
                x: 1910,
                y: 0,
                width: 10,
                height: 1024,
                levelIndex: 1,
                playerPosition: { x: 40, y: 490 }
            }
        ]
    });

})();