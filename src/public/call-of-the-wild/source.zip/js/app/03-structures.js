(function () { // :)
    'use strict';

    grove.objectTemplates.Tree = function(stats) {
        this.size = { width: 206, height: 214 };
        this.position = { x: 0, y: 0 };
        this.physicsBody = { x: 85, y: 172, width: 31, height: 38 };

        if (typeof stats !== typeof undefined) {
            if (typeof stats.width !== typeof undefined) { this.size.width = stats.width; }
            if (typeof stats.height !== typeof undefined) { this.size.height = stats.height; }
            if (typeof stats.x !== typeof undefined) { this.position.x = stats.x; }
            if (typeof stats.y !== typeof undefined) { this.position.y = stats.y; }
        }
    };

    grove.objectTemplates.Goal = function(stats) {
        this.position = { x: 0, y: 0 };
        this.playerPosition = { x: 500, y: 500 };
        this.size = { width: 0, height: 0 };
        this.collide = false;
        this.levelIndex = 0;
        this.collide = true;

        if (typeof stats !== typeof undefined) {
            if (typeof stats.width !== typeof undefined) { this.size.width = stats.width; }
            if (typeof stats.height !== typeof undefined) { this.size.height = stats.height; }
            if (typeof stats.x !== typeof undefined) { this.position.x = stats.x; }
            if (typeof stats.y !== typeof undefined) { this.position.y = stats.y; }
            if (typeof stats.levelIndex !== typeof undefined) { this.levelIndex = stats.levelIndex; }
            if (typeof stats.playerPosition !== typeof undefined) { this.playerPosition = stats.playerPosition; }
        }

        this.draw = function(context) {
            // debug draw code 
            /*
            context.fillStyle = '#fff';
            context.fillRect(this.position.x, this.position.y, this.size.width, this.size.height);
            */
        };

        this.update = function() {
            if (this.collide) {
                // check for player
                var touchingHero = grove.checkForCollision(grove.hero, this);
                if (touchingHero) {
                    this.awardGoal();
                }
            }
        };

        this.awardGoal = function() {
            grove.hero.position.x = this.playerPosition.x;
            grove.hero.position.y = this.playerPosition.y;
            grove.changeLevel(this.levelIndex);
        };
    };

})(); // :D