(function () { // :)
    'use strict';

    grove.levels.push({
        backgroundImageSrc: 'img/background-level-5.jpg',

        edgeAdjustments: {
            left: 70,
            top: 0,
            right: 70,
            bottom: 0
        },


        elementals: [
        ],

        trees: [
            { x: 50, y: 700 },
            { x: 1600, y: 700 },
        ],

        goals: [
            {   // to the left!
                x: 0,
                y: 0,
                width: 10,
                height: 1024,
                levelIndex: 4,
                playerPosition: { x: 1780, y: 490 }
            },
        ]
    });

})();