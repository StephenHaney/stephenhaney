(function () { // :)
    'use strict';

    grove.levels.push({
        backgroundImageSrc: 'img/background-level-2.jpg',

        edgeAdjustments: {
            left: 0,
            top: 70,
            right: 0,
            bottom: 70
        },


        elementals: [
            { x: 100, y: 490 },
            { x: 1800, y: 490 }
        ],

        trees: [
            { x: 20, y: 530 },
            { x: 70, y: 530 },
            { x: 140, y: 530 },
            { x: 210, y: 530 },
            { x: 280, y: 530 },
            { x: 350, y: 530 },
            { x: 420, y: 530 },
            { x: 490, y: 530 },
            { x: 560, y: 530 },
            { x: 630, y: 530 },
            { x: 700, y: 530 },
            { x: 770, y: 530 },
            { x: 840, y: 530 },
            { x: 910, y: 530 },
            { x: 980, y: 530 },
            { x: 1050, y: 530 },
            { x: 1120, y: 530 },
            { x: 1190, y: 530 },
            { x: 1260, y: 530 },
            { x: 1330, y: 530 },
            { x: 1400, y: 530 },
            { x: 1470, y: 530 },
            { x: 1540, y: 530 },
            { x: 1610, y: 530 },
            { x: 1680, y: 530 },
            { x: 1730, y: 530 }
        ],

        goals: [
            {   // to the top!
                x: 0,
                y: 0,
                width: 1920,
                height: 10,
                levelIndex: 1,
                playerPosition: { x: 900, y: 884 }
            },
            {   // to the bottom!
                x: 0,
                y: 1014,
                width: 1920,
                height: 10,
                levelIndex: 3,
                playerPosition: { x: 900, y: 40 }
            },
        ]
    });

})();