(function () { // :)
    'use strict';

    grove.objectTemplates.Fireball = function(stats) {
        // defaults stats:
        this.speed = 5.25;
        this.size = { width: 32, height: 32 };
        this.position = { x: 500, y: 500 };
        this.opacity = 1;
        this.collide = true;
        this.damage = 20;
        this.vector = {
            x: 0,
            y: 0
        };

        if (typeof stats !== typeof undefined) {
            if (typeof stats.x !== typeof undefined) { this.position.x = stats.x; }
            if (typeof stats.y !== typeof undefined) { this.position.y = stats.y; }
            if (typeof stats.vectorX !== typeof undefined) { this.vector.x = stats.vectorX; }
            if (typeof stats.vectorY !== typeof undefined) { this.vector.y = stats.vectorY; }
        }

        this.animationFrame = 0;
        this.animationFrameCount = 3; // 0 based count
        this.timeSinceLastAnimation = 0;
        this.millisecondsPerFrame = 6;

        this.image = new Image();
        this.image.src = 'img/bad-fireball.png';

        this.draw = function(deltaTime) {
            var frameX = this.animationFrame * this.size.width;
            var frameY = 0;

            grove.ctxAction.drawImage(this.image, frameX, frameY, this.size.width, this.size.height, this.position.x, this.position.y, this.size.width, this.size.height);
        };

        this.update = function(deltaTime) {
            // Logic for the animation
            this.timeSinceLastAnimation += deltaTime;
            if (this.timeSinceLastAnimation > this.millisecondsPerFrame) {
                this.timeSinceLastAnimation = 0;
                this.animationFrame++;
                if (this.animationFrame > this.animationFrameCount) { this.animationFrame = 0; }
            }

            if (this.collide && grove.hero.flying === false) {
                // check for eating our hero
                var kaboom = grove.checkForCollision(grove.hero, this);
                if (kaboom !== false) {
                    grove.hero.damage(this.damage);
                }
            }

            this.performMovement(deltaTime, this.vector);
        };

        this.performMovement = function(deltaTime, vector) {
            // we have movement
            var length = Math.sqrt(vector.x * vector.x + vector.y * vector.y);

            var distanceMoved = {
                x: 0,
                y: 0
            };

            if (vector.x !== 0) {
                distanceMoved.x = vector.x / length * this.speed * deltaTime;
                this.position.x += distanceMoved.x;
            }
            if (vector.y !== 0) {
                distanceMoved.y = vector.y / length * this.speed * deltaTime;
                this.position.y += distanceMoved.y;
            }

            return distanceMoved;
        };
    };

})(); // :D