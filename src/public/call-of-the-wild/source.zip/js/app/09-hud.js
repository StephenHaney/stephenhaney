(function () { // :)
    'use strict';

    grove.objectTemplates.Hud = function() {
        this.size = { width: 486, height: 191 };
        this.position = { x: 20, y: 20 };
        this.spriteOffset = { x: 1, y: 1};

        // drives the sprite offsets used for the various forms:
        this.currentOffsetName = 'druid';

        /* portrait info */
        this.portrait = {
            size: {
                width: 114,
                height: 114,
            },
            position: {
                x: 36 + this.position.x,
                y: 30 + this.position.y
            }
        };
        this.portraitOffsets = {
            druid: { x: 0, y: 193 },
            wolf: { x: 115, y: 193 },
            owl: { x: 230, y: 193 }
        };

        /* ability icon info */
        this.icon = {
            size: {
                width: 69,
                height: 69
            },
            position: {
                x: 154 + this.position.x,
                y: 73 + this.position.y
            }
        };
        this.iconOffsets = {
            druid: { x: 489, y: 0 },
            wolf: { x: 559, y: 0 },
            owl: { x: 629, y: 0 }
        };

        /* health bar info */
        this.healthBar = {
            size: {
                width: 294,
                height: 35
            },
            position: {
                x: 154 + this.position.x,
                y: 30 + this.position.y,
            },
            healthSpriteOffset: { x: 0, y: 318 },
            damageSpriteOffset: { x: 0, y: 354 }
        };

        this.image = new Image();
        this.image.src = 'img/hud.png';

        this.draw = function() {
            grove.ctxGui.clearRect(this.position.x, this.position.y, this.size.width, this.size.height);

            // Draw the portrait:
            var currentPortrait = this.portraitOffsets[this.currentOffsetName];
            grove.ctxGui.drawImage(this.image, currentPortrait.x, currentPortrait.y, this.portrait.size.width, this.portrait.size.height, this.portrait.position.x, this.portrait.position.y, this.portrait.size.width, this.portrait.size.height);

            // Draw damage:
            grove.ctxGui.drawImage(this.image, this.healthBar.damageSpriteOffset.x, this.healthBar.damageSpriteOffset.y, this.healthBar.size.width, this.healthBar.size.height, this.healthBar.position.x, this.healthBar.position.y, this.healthBar.size.width, this.healthBar.size.height);
            // Draw health:
            var healthBarSize = this.healthBar.size.width * grove.hero.displayLife / grove.hero.initialLife;
            grove.ctxGui.drawImage(this.image, this.healthBar.healthSpriteOffset.x, this.healthBar.healthSpriteOffset.y, healthBarSize, this.healthBar.size.height, this.healthBar.position.x, this.healthBar.position.y, healthBarSize, this.healthBar.size.height);

            // Draw ability icon:
            var currentIcon = this.iconOffsets[this.currentOffsetName];
            grove.ctxGui.drawImage(this.image, currentIcon.x, currentIcon.y, this.icon.size.width, this.icon.size.height, this.icon.position.x, this.icon.position.y, this.icon.size.width, this.icon.size.height);

            // Draw the HUD frame:
            grove.ctxGui.drawImage(this.image, this.spriteOffset.x, this.spriteOffset.y, this.size.width, this.size.height, this.position.x, this.position.y, this.size.width, this.size.height);
        };

        this.switchForm = function(newFormName) {
            this.currentOffsetName = newFormName;
            this.draw();
        };

        this.updateHealthBar = function() {

        };
    };

})(); // :D