(function () { // :)
    'use strict';

    grove.objectTemplates.badFireElemental = function(stats) {
        // defaults stats:
        this.speed = 1.2;
        this.size = { width: 64, height: 96 };
        this.position = { x: 500, y: 500 };
        this.route = [];
        this.loop = true;  // default behavior is to loop the route, set to false for reverse
        this.opacity = 1;
        this.collide = true;
        this.followHero = true;
        this.damage = 10;
        this.initialHealth = 30;
        this.health = this.initialHealth;
        this.scale = 1;

        this.lastDamageTaken = 0;

        this.fireballCastingTime = 800;
        this.fireballDelay = 5000;
        this.lastFireball = Date.now();

        this.image = new Image();
        this.image.src = 'img/bad-fire-chick.png';

        this.millisecondsPerFrame = 6;
        this.animationFrameCount = 3; // 0 based count
        this.animationFrame = 0;
        this.timeSinceLastAnimation = 0;

        var self = this;
        var currentPath = 0;
        var currentPathDirection = 1;
        var xGoalMet = false;
        var yGoalMet = false;

        if (typeof stats !== typeof undefined) {
            if (typeof stats.width !== typeof undefined) { this.size.width = stats.width; }
            if (typeof stats.height !== typeof undefined) { this.size.height = stats.height; }
            if (typeof stats.speed !== typeof undefined) { this.speed = stats.speed; }
            if (typeof stats.image !== typeof undefined) { this.image = stats.image; }
            if (typeof stats.loop !== typeof undefined) { this.loop = stats.loop; }
            if (typeof stats.x !== typeof undefined) { this.position.x = stats.x; }
            if (typeof stats.y !== typeof undefined) { this.position.y = stats.y; }
            if (typeof stats.route !== typeof undefined) {
                this.route = stats.route;
                this.position.x = this.route[0].x;
                this.position.y = this.route[0].y;

                if (this.route.length > 1) {
                    nextDestination();
                }
            }
        }

        this.launchFireball = function(vector) {
            this.castingFireball = true;

            var self = this;
            setTimeout(function() {
                // no fireballs if we died while casting
                if (self.health <= 0) { self.castingFireball = false; return; }
                // set the fireball's position and vector
                var fireballStats = {
                    x: self.position.x,
                    y: self.position.y,
                    vectorX: vector.x,
                    vectorY: vector.y
                };
                grove.sounds.fireball.play();
                // Spawn the fireball:
                var newFireball = new grove.objectTemplates.Fireball(fireballStats);
                grove.fireballs.push(newFireball);
                // stop casting after another delay
                setTimeout(function() {
                    self.castingFireball = false;
                }, 500);
            }, this.fireballCastingTime);
        };

        this.takeDamage = function(damage) {
            var current = Date.now();
            // throttle
            if (current > this.lastDamageTaken + 500) {
                this.lastDamageTaken = current;
                this.health -= damage;
                this.opacity = 0.5 + this.health / this.initialHealth;
                this.scale = 0.5 + this.health / this.initialHealth;
                if (this.scale < 0.2) { this.scale = 0.2; }
                if (this.scale > 1) { this.scale = 1; }

                if (this.health <= 0) {
                    this.opacity = 0.3;
                }
                if (grove.hero.lastDirection.both === 0) {
                    // down
                    tween.to(this.position, 0.3, { y: '+=100' });
                }
                else if (grove.hero.lastDirection.both === 1) {
                    // left
                    tween.to(this.position, 0.3, { x: '-=100' });
                }
                else if (grove.hero.lastDirection.both === 2) {
                    // right
                    tween.to(this.position, 0.3, { x: '+=100' });
                }
                else if (grove.hero.lastDirection.both === 3) {
                    // up
                    tween.to(this.position, 0.3, { y: '-=100' });
                }
            }
        };

        this.draw = function(deltaTime) {
            //var frameY = this.lastDirection.both * this.size.height;
            var frameX = this.animationFrame * this.size.width;

            if (this.opacity !== 1) {
                grove.ctxAction.globalAlpha = this.opacity;
                grove.ctxAction.drawImage(this.image, frameX, 0, this.size.width, this.size.height, this.position.x, this.position.y, this.size.width * this.scale, this.size.height * this.scale);
                grove.ctxAction.globalAlpha = 1;
            }
            else {
                grove.ctxAction.drawImage(this.image, frameX, 0, this.size.width, this.size.height, this.position.x, this.position.y, this.size.width * this.scale, this.size.height * this.scale);
            }
        };

        this.update = function(deltaTime) {
            if (this.health <= 0) { return; }
            if (this.collide && grove.hero.flying === false) {
                // check for eating our hero
                var omnomnom = grove.checkForCollision(grove.hero, this);
                if (omnomnom !== false) {
                    grove.hero.damage(this.damage);
                }
            }

            // Logic for the burning animation
            this.timeSinceLastAnimation += deltaTime;
            if (this.timeSinceLastAnimation > this.millisecondsPerFrame) {
                this.timeSinceLastAnimation = 0;
                this.animationFrame++;
                if (this.animationFrame > this.animationFrameCount) { this.animationFrame = 0; }
            }

            var vector = { x: 0, y: 0 };
            if (this.followHero && grove.hero.flying === false) {
                // Move towards the hero
                vector.x = grove.hero.position.x - this.position.x;
                vector.y = grove.hero.position.y - this.position.y;

                this.performMovement(deltaTime, vector);
            }
            else if (this.route.length > 1)
            {
                // Follow a route
                vector.x = this.route[currentPath].x - this.position.x;
                vector.y = this.route[currentPath].y - this.position.y;

                if (vector.x !== 0 || vector.y !== 0) {
                    var distanceMoved = this.performMovement(deltaTime, vector);

                    vector.x = Math.floor(vector.x);
                    vector.y = Math.floor(vector.y);

                    // troubleshooting code if NPCs are getting stuck
                    /*this.lastDistance = distanceMoved;
                    this.lastVector = vector;*/

                    // adjust for going over and check for being done
                    // floor the vector and +1 the distance moved, so if we're 'close' to the goal, it's good enough
                    // or the npc can be stuck foreverrrrrrr
                    if (Math.abs(distanceMoved.x) + 1 >= Math.abs(vector.x)) {
                        this.position.x = this.route[currentPath].x;
                        xGoalMet = true;
                    }

                    if (Math.abs(distanceMoved.y) + 1 >= Math.abs(vector.y)) {
                        yGoalMet = true;
                        this.position.y = this.route[currentPath].y;
                    }

                    if (xGoalMet && yGoalMet) {
                        nextDestination();
                    }
                }
                else {
                    // troubleshooting code if NPCs are getting stuck
                    /*if (xGoalMet === false || yGoalMet === false)
                    {
                        if (this.reported < 50) {
                            // no movement
                            console.log('no!');

                            console.log('path x: ' + this.route[currentPath].x);
                            console.log('path y: ' + this.route[currentPath].y);
                            console.log('current x: ' + this.position.x);
                            console.log('current y: ' + this.position.y);

                            console.log('last vector x: ' + this.lastVector.x);
                            console.log('last vector y: ' + this.lastVector.y);
                            console.log('last distance x: ' + this.lastDistance.x);
                            console.log('last distance y: ' + this.lastDistance.y);

                            this.reported++;
                        }
                    }*/
                }

            }
        };

        // troubleshooting code if NPCs are getting stuck
        /*this.reported = 0;
        this.lastVector = null;
        this.lastDistance = null;*/

        function nextDestination() {
            var nextStepIndex = currentPath + currentPathDirection;

            if (nextStepIndex === self.route.length) {
                // we're at the max
                if (self.loop) {
                    // if we're looping, go back to 0
                    nextStepIndex = 0;
                }
                else {
                    // otherwise go in reverse
                    currentPathDirection = -1;
                    // we just hit max, so to reverse: next route is -2 from overshoot test
                    nextStepIndex += -2;
                }
            }
            else if (nextStepIndex === -1) {
                currentPathDirection = 1;
                // we just hit 0, so to reverse: next route is 1
                nextStepIndex = 1;
            }

            if (typeof self.route[currentPath].pause !== typeof undefined) {
                setTimeout(function() {
                    currentPath = nextStepIndex;
                    xGoalMet = false;
                    yGoalMet = false;
                }, self.route[currentPath].pause);
            }
            else {
                currentPath = nextStepIndex;
                xGoalMet = false;
                yGoalMet = false;
            }
        }

        this.performMovement = function(deltaTime, vector) {
            // don't move if we're already casting a fireball
            if (this.castingFireball) { return; }

            // Check if we should launch a fireball instead of moving
            var current = Date.now();
            if (current > this.lastFireball + this.fireballDelay) {
                // launch a fireball!
                this.lastFireball = current;
                this.launchFireball(vector);
                return;
            }

            // we have movement
            var length = Math.sqrt(vector.x * vector.x + vector.y * vector.y);
            var distanceMoved = {
                x: 0,
                y: 0
            };

            if (vector.x !== 0) {
                distanceMoved.x = vector.x / length * this.speed * deltaTime;
                this.position.x += distanceMoved.x;
            }
            if (vector.y !== 0) {
                distanceMoved.y = vector.y / length * this.speed * deltaTime;
                this.position.y += distanceMoved.y;
            }

            return distanceMoved;
        };
    };

})(); // :D