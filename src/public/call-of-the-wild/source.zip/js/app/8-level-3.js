(function () { // :)
    'use strict';

    grove.levels.push({
        backgroundImageSrc: 'img/background-level-3.jpg',

        edgeAdjustments: {
            left: 0,
            top: 70,
            right: 70,
            bottom: 0
        },


        elementals: [
            { x: 400, y: 490 },
            { x: 600, y: 490 },
            { x: 800, y: 490 },
            { x: 200, y: 800 },
            { x: 700, y: 800 },
            { x: 1500, y: 800 }
        ],

        trees: [
            { x: 50, y: 500 },
            { x: 1560, y: 680 },
        ],

        goals: [
            {   // to the top!
                x: 0,
                y: 0,
                width: 1920,
                height: 10,
                levelIndex: 2,
                playerPosition: { x: 900, y: 884 }
            },
            {   // to the right!
                x: 1910,
                y: 0,
                width: 10,
                height: 1024,
                levelIndex: 4,
                playerPosition: { x: 40, y: 490 }
            }
        ]
    });

})();